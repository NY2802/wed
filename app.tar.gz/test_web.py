import flet as ft
import random
import threading
import time

def main(page: ft.Page):
    page.title = "Snake Game"
    page.theme_mode = "dark"
    page.window.width = 500
    page.window.height = 700
    page.horizontal_alignment = "center"

    # Параметры игры
    TILE_SIZE = 20
    GAME_SIZE = 400

    # Используем словарь для хранения состояния (чтобы избежать global)
    gs = {
        "run": True,
        "snake": [[100, 100], [80, 100], [60, 100]],
        "food": [200, 200],
        "dir": [TILE_SIZE, 0],
        "score": 0,
        "restart_btn": None
    }

    score_text = ft.Text(f"Счет: 0", size=30, weight="bold")
    game_stack = ft.Stack(width=GAME_SIZE, height=GAME_SIZE)
    
    # Поле
    field = ft.Container(
        content=game_stack,
        width=GAME_SIZE,
        height=GAME_SIZE,
        bgcolor="#111111",
        border=ft.border.all(2, "white"),
        border_radius=10
    )

    def draw():
        # Быстрая перерисовка без анимаций
        game_stack.controls.clear()
        
        # Рисуем еду
        game_stack.controls.append(
            ft.Container(
                width=TILE_SIZE-1, height=TILE_SIZE-1, 
                bgcolor="red", left=gs["food"][0], top=gs["food"][1],
                border_radius=5
            )
        )
        
        # Рисуем змейку
        for i, seg in enumerate(gs["snake"]):
            game_stack.controls.append(
                ft.Container(
                    width=TILE_SIZE-1, height=TILE_SIZE-1, 
                    bgcolor="green" if i == 0 else "#007000",
                    left=seg[0], top=seg[1],
                    border_radius=4
                )
            )
        page.update()

    def game_loop():
        while gs["run"]:
            # Новая голова
            head = [gs["snake"][0][0] + gs["dir"][0], gs["snake"][0][1] + gs["dir"][1]]
            
            # Проверка столкновений (стены и хвост)
            if (head[0] < 0 or head[0] >= GAME_SIZE or 
                head[1] < 0 or head[1] >= GAME_SIZE or 
                head in gs["snake"]):
                gs["run"] = False
                break

            gs["snake"].insert(0, head)

            # Проверка еды
            if head == gs["food"]:
                gs["score"] += 10
                score_text.value = f"Счет: {gs['score']}" # Исправлены кавычки
                gs["food"] = [
                    random.randrange(0, GAME_SIZE, TILE_SIZE), 
                    random.randrange(0, GAME_SIZE, TILE_SIZE)
                ]
            else:
                gs["snake"].pop()

            draw()
            time.sleep(0.12) # Скорость

        # Конец игры
        score_text.value = "ИГРА ОКОНЧЕНА!"
        show_button()
        page.update()

    def show_button():
        # Создаем кнопку через content (требование 0.80+)
        gs["restart_btn"] = ft.TextButton(
            content=ft.Text("ИГРАТЬ ЗАНОВО", size=50, color="blue", weight="bold"),
            on_click=restart_game
        )
        page.add(gs["restart_btn"])

    def restart_game(e):
        # Удаляем кнопку и сбрасываем всё
        if gs["restart_btn"]:
            page.remove(gs["restart_btn"])
        
        gs["run"] = True
        gs["score"] = 0
        gs["snake"] = [[100, 100], [80, 100], [60, 100]]
        gs["dir"] = [TILE_SIZE, 0]
        gs["food"] = [200, 200]
        score_text.value = "Счет: 0"
        
        # Запускаем новый поток игры
        threading.Thread(target=game_loop, daemon=True).start()

    def on_key(e: ft.KeyboardEvent):
        d = gs["dir"]
        # Извлекаем название клавиши и переводим в ВЕРХНИЙ регистр
        k = e.key.upper() 
        
        # Условия теперь заработают правильно
        if (k == "ARROW UP" or k == "W") and d[1] == 0:
            gs["dir"] = [0, -TILE_SIZE]
        elif (k == "ARROW DOWN" or k == "S") and d[1] == 0:
            gs["dir"] = [0, TILE_SIZE]
        elif (k == "ARROW LEFT" or k == "A") and d[0] == 0:
            gs["dir"] = [-TILE_SIZE, 0]
        elif (k == "ARROW RIGHT" or k == "D") and d[0] == 0:
            gs["dir"] = [TILE_SIZE, 0]

    page.on_keyboard_event = on_key
    def joy_btn(icon, key):
        return ft.IconButton(icon=icon, icon_size=40, on_click=lambda _: on_key(ft.KeyboardEvent(key=key, shift=False, ctrl=False, alt=False, meta=False)))

    joystick = ft.Column([
        ft.Row([joy_btn("arrow_upward", "Arrow Up")], alignment="center"),
        ft.Row([joy_btn("arrow_back", "Arrow Left"), ft.Container(width=40), joy_btn("arrow_forward", "Arrow Right")], alignment="center"),
        ft.Row([joy_btn("arrow_downward", "Arrow Down")], alignment="center"),
    ], spacing=0, visible=False)

    # Отображаем джойстик на мобилках или если это веб-версия
    if page.platform in [ft.PagePlatform.ANDROID, ft.PagePlatform.IOS] or page.web:
        joystick.visible = True

    page.on_keyboard_event = on_key
    page.add(score_text, field, ft.Container(height=10), joystick)
    threading.Thread(target=game_loop, daemon=True).start()

if __name__ == "__main__":
    ft.run(main)
